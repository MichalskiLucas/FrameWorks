package br.com.unipar.hibernateteste.model.enums;

public enum SituacaoEnum {

    PENDENTE, EM_ANDAMENTO, CONCLUIDO, NAO_COMPARECEU, CANCELADO;
    
}
