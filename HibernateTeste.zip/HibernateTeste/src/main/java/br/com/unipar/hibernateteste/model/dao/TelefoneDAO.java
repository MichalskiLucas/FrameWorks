package br.com.unipar.hibernateteste.model.dao;

import br.com.unipar.hibernateteste.model.usuario.Telefone;

public class TelefoneDAO extends GenericDAO<Telefone>{
     public TelefoneDAO() {
        super(Telefone.class);
    }
}
