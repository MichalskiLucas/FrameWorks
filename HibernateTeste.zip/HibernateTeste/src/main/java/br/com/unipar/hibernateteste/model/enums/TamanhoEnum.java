package br.com.unipar.hibernateteste.model.enums;

public enum TamanhoEnum {
  MINI,PEQUENO,MEDIO,GRANDE;    
}
