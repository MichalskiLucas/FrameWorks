package br.com.unipar.hibernateteste.model.enums;

public enum TipoTelefoneEnum {

    CASA, TRABALHO, CELULAR;
    
}
