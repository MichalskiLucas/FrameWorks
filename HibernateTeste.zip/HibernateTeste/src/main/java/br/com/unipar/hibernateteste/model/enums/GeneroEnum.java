package br.com.unipar.hibernateteste.model.enums;

public enum GeneroEnum {

    MACHO, FEMEA
    
}
