package br.com.unipar.hibernateteste.model.dao;

import br.com.unipar.hibernateteste.model.usuario.Estado;

public class EstadoDAO extends GenericDAO<Estado> {

    public EstadoDAO() {
        super(Estado.class);
    }
}
