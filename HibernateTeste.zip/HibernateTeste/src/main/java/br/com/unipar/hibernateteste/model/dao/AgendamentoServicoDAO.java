package br.com.unipar.hibernateteste.model.dao;

import br.com.unipar.hibernateteste.model.usuario.AgendamentoServico;
public class AgendamentoServicoDAO extends GenericDAO<AgendamentoServico>{

    public AgendamentoServicoDAO(){
        super(AgendamentoServico.class);
    }
    
}
