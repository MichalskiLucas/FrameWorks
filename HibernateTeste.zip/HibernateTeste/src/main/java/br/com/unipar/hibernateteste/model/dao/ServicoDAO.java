package br.com.unipar.hibernateteste.model.dao;

import br.com.unipar.hibernateteste.model.usuario.Servico;

public class ServicoDAO extends GenericDAO<Servico>{
  public ServicoDAO() {
        super(Servico.class);
    }
}
